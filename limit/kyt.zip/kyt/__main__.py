from kyt import *
from importlib import import_module
from kyt.modules import ALL_MODULES

# Memuat semua modul tanpa validasi admin
for module_name in ALL_MODULES:
    import_module("kyt.modules." + module_name)

# Menjalankan bot tanpa pembatasan admin
bot.run_until_disconnected()
