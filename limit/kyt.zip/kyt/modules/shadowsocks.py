from kyt import *
import subprocess
import time
import requests
import re
import datetime as DT

# CREATE SHADOWSOCKS ACCOUNT
@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
    chat = event.chat_id
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    await event.respond("**Quota:**")
    quota_input = await bot.wait_for(events.NewMessage(incoming=True))
    quota = quota_input.raw_text

    await event.respond("**Expired Days:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" | addss'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))
    links = [x.group() for x in re.finditer("ss://(.*)", result)]
    uuid = re.search("ss://(.*?)@", links[0]).group(1)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ SHADOWSOCKS ACCOUNT 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Remarks:** `{user}`
🔰 **Host Server:** `{DOMAIN}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `Unlimited`
🔰 **Pub Key:** `{PUB}`
🔰 **Port TLS:** `222-1000`
🔰 **Port GRPC:** `443`
🔰 **Port DNS:** `443, 53`
🔰 **Password:** `{uuid}`
🔰 **Ciphers:** `aes-128-gcm`
🔰 **Network:** `(WS) or (gRPC)`
🔰 **Path:** `(/multi path)/ss-ws`
🔰 **ServiceName:** `ss-grpc`
━━━━━━━━━━━━━━━━━
🔰 **Link TLS:** `{links[0]}`
━━━━━━━━━━━━━━━━━
🔰 **Link gRPC:** `{links[1].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Link JSON:** `https://{DOMAIN}:81/ss-{user}.txt`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{later}`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# CHECK SHADOWSOCKS LOGGED-IN USERS
@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
    cmd = 'bot-cek-ss'
    result = subprocess.getoutput(cmd)
    await event.respond(f"""
{result}
**Shows Logged In Users Shadowsocks**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# DELETE SHADOWSOCKS ACCOUNT
@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    cmd = f'printf "%s\n" "{user}" | del-ss'
    result = subprocess.getoutput(cmd)

    if "not found" in result.lower():
        await event.respond("**User Not Found**")
    else:
        await event.respond("**Successfully Deleted**")

# TRIAL SHADOWSOCKS ACCOUNT
@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
    await event.respond("**Expired Minutes:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{exp}" | trialss'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    links = [x.group() for x in re.finditer("ss://(.*)", result)]
    remarks = re.search("#(.*)", links[0]).group(1)
    uuid = re.search("ss://(.*?)@", links[0]).group(1)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ SHADOWSOCKS TRIAL 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Remarks:** `{remarks}`
🔰 **Host Server:** `{DOMAIN}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `Unlimited`
🔰 **Pub Key:** `{PUB}`
🔰 **Port TLS:** `222-1000`
🔰 **Port GRPC:** `443`
🔰 **Port DNS:** `443, 53`
🔰 **Password:** `{uuid}`
🔰 **Ciphers:** `aes-128-gcm`
🔰 **Network:** `(WS) or (gRPC)`
🔰 **Path:** `(/multi path)/ss-ws`
🔰 **ServiceName:** `ss-grpc`
━━━━━━━━━━━━━━━━━
🔰 **Link TLS:** `{links[0]}`
━━━━━━━━━━━━━━━━━
🔰 **Link gRPC:** `{links[1].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Link JSON:** `https://{DOMAIN}:81/ss-{remarks}.txt`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{exp} Minutes`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# SHADOWSOCKS MENU
@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
    inline = [
        [Button.inline(" TRIAL SHDWSCSK ", "trial-shadowsocks"),
         Button.inline(" CREATE SHDWSCSK ", "create-shadowsocks")],
        [Button.inline(" CHECK SHDWSCSK ", "cek-shadowsocks"),
         Button.inline(" DELETE SHDWSCSK ", "delete-shadowsocks")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ SHADOWSOCKS MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `SHADOWSOCKS`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🔰 **🤖 @sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)