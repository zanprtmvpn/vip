from kyt import *
import subprocess
import time
import requests
import re
import json
import base64
import datetime as DT

# CREATE SHADOWSOCKS ACCOUNT
@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
    async with bot.conversation(chat) as user:
        await event.respond('**Username:**')
        user = (await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    async with bot.conversation(chat) as pw:
        await event.respond("**Quota:**")
        pw = (await pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    # Tambahkan menu pemilihan waktu di sini
    inline_time = [
        [Button.inline("1 Day", "1day"), Button.inline("3 Days", "3days")],
        [Button.inline("7 Days", "7days"), Button.inline("30 Days", "30days")],
        [Button.inline("‹ Back", "shadowsocks")]
    ]
    await event.edit("**Please select the expiration time for the Shadowsocks account**", buttons=inline_time)

    @bot.on(events.CallbackQuery(data=b'1day'))
    async def one_day(event):
        await process_shadowsocks_creation(event, user, pw, '1')
    
    @bot.on(events.CallbackQuery(data=b'3days'))
    async def three_days(event):
        await process_shadowsocks_creation(event, user, pw, '3')
    
    @bot.on(events.CallbackQuery(data=b'7days'))
    async def seven_days(event):
        await process_shadowsocks_creation(event, user, pw, '7')
    
    @bot.on(events.CallbackQuery(data=b'30days'))
    async def thirty_days(event):
        await process_shadowsocks_creation(event, user, pw, '30')

# Function to process Shadowsocks creation
async def process_shadowsocks_creation(event, user, pw, exp):
    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addss'
    try:
        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
        await event.respond("**User Already Exist**")
        return

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))
    x = [x.group() for x in re.finditer("ss://(.*)", a)]
    uuid = re.search("ss://(.*?)@", x[0]).group(1)
    msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SHDWSCSK ACCOUNT 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `Unlimited`
**» Pub Key     :** `{PUB}`
**» Port TLS    :** `222-1000`
**» Port GRPC   :** `443`
**» Port DNS    :** `443, 53`
**» Password    :** `{uuid}`
**» Cipers      :** `aes-128-gcm`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `(/multi path)/ss-ws`
**» ServiceName :** `ss-grpc`
**━━━━━━━━━━━━━━━━━**
**» Link TLS    :**
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**» Link gRPC   :** 
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link JSON  :** `https://${DOMAIN}:81/ss-{user}.txt`
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@sabdestore**
"""
    await event.respond(msg)

# CHECK SHADOWSOCKS LOGGED-IN USERS
@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
    cmd = 'bot-cek-ss'
    result = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
{result}

**Shows Logged In Users Shadowsocks**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# DELETE SHADOWSOCKS ACCOUNT
@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    async with bot.conversation(chat) as user:
        await event.respond('**Username:**')
        user = (await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
    cmd = f'printf "%s\n" "{user}" | del-ss'
    result = subprocess.check_output(cmd, shell=True).decode("utf-8")

    if "not found" in result.lower():
        await event.respond("**User Not Found**")
    else:
        await event.respond(f"**Successfully Deleted** `{user}`")

# TRIAL SHADOWSOCKS ACCOUNT
@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
    async with bot.conversation(chat) as exp:
        await event.respond("**Expired Minutes:**")
        exp = (await exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{exp}" | trialss'
    try:
        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
        await event.respond("**User Already Exist**")
        return

    x = [x.group() for x in re.finditer("ss://(.*)", a)]
    remarks = re.search("#(.*)", x[0]).group(1)
    uuid = re.search("ss://(.*?)@", x[0]).group(1)
    msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SHDWSCSK Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `Unlimited`
**» Pub Key     :** `{PUB}`
**» Port TLS    :** `222-1000`
**» Port GRPC   :** `443`
**» Port DNS    :** `443, 53`
**» Password    :** `{uuid}`
**» Cipers      :** `aes-128-gcm`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `(/multi path)/ss-ws`
**» ServiceName :** `ss-grpc`
**━━━━━━━━━━━━━━━━━**
**» Link TLS    :**
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**» Link gRPC   :** 
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link JSON  :** `https://${DOMAIN}:81/ss-{remarks}.txt`
**━━━━━━━━━━━━━━━━━**
**» Expired Until :** `{exp} Minutes`
**» 🤖@sabdestore**
"""
    await event.respond(msg)

# SHADOWSOCKS MANAGER MENU
@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
    inline = [
        [Button.inline(" TRIAL SHDWSCSK ", "trial-shadowsocks"),
         Button.inline(" CREATE SHDWSCSK ", "create-shadowsocks")],
        [Button.inline(" CHECK SHDWSCSK ", "cek-shadowsocks"),
         Button.inline(" DELETE SHDWSCSK ", "delete-shadowsocks")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ SHDWSK MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `SHADOWSOCKS`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🔰 **🤖 @sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)
