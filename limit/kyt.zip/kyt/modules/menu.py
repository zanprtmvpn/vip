from kyt import *
import subprocess

# Fungsi untuk membaca variabel dari var.txt
def get_var(variable):
    try:
        with open("/usr/bin/kyt/var.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                if line.startswith(variable + "="):
                    return line.strip().split('=')[1].strip('"')
    except:
        return None  # Jika variabel tidak ditemukan

# Load konfigurasi dari var.txt
DOMAIN = get_var("DOMAIN")
PUB = get_var("PUB")
NS = get_var("HOST")

# Fungsi untuk validasi admin
def valid(sender_id):
    with open("/usr/bin/kyt/var.txt", "r") as file:
        lines = file.readlines()
    for line in lines:
        if line.startswith("ADMIN_IDS="):
            admin_ids = line.strip().split('=')[1].strip('"')  # Ambil daftar admin
            admin_list = admin_ids.split()  # Pisahkan ID admin yang dipisahkan spasi
            return "true" if str(sender_id) in admin_list else "false"
    return "false"  # Default "false" jika tidak ada ADMIN_IDS

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"), Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan"), Button.inline(" SHDWSK MANAGER ", "shadowsocks")],
        [Button.inline(" CHECK VPS INFO ", "info"), Button.inline(" OTHER SETTING ", "setting")],
        [Button.inline(" ‹ Back Menu › ", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Eksekusi command untuk mendapatkan jumlah akun yang dibuat
        ssh = subprocess.getoutput('cat /etc/ssh/.ssh.db | grep "###" | wc -l')
        vms = subprocess.getoutput('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
        vls = subprocess.getoutput('cat /etc/vless/.vless.db | grep "###" | wc -l')
        trj = subprocess.getoutput('cat /etc/trojan/.trojan.db | grep "###" | wc -l')
        
        # Informasi sistem dan VPS
        namaos = subprocess.getoutput("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"', '')
        ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
        city = subprocess.getoutput("cat /etc/xray/city")

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ ADMIN PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos.strip()}`
**» CITY   :** `{city.strip()}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)
