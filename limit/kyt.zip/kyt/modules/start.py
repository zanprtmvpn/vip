from kyt import *
import subprocess

# Fungsi untuk membaca variabel dari var.txt
def get_var(variable):
    try:
        with open("/usr/bin/kyt/var.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                if line.startswith(variable + "="):
                    return line.strip().split('=')[1].strip('"')
    except:
        return None  # Jika variabel tidak ditemukan

# Load konfigurasi dari var.txt
DOMAIN = get_var("DOMAIN")
PUB = get_var("PUB")
NS = get_var("HOST")

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT", "menu")],
        [Button.url("TELEGRAM GROUP", "https://t.me/sabdestore_vpn"),
         Button.url("ORDER SCRIPT", "https://t.me/sabdestore")]
    ]

    # Eksekusi command untuk mendapatkan jumlah akun yang dibuat
    ssh = subprocess.getoutput('cat /etc/ssh/.ssh.db | grep "###" | wc -l')
    vms = subprocess.getoutput('cat /etc/vmess/.vmess.db | grep "###" | wc -l')
    vls = subprocess.getoutput('cat /etc/vless/.vless.db | grep "###" | wc -l')
    trj = subprocess.getoutput('cat /etc/trojan/.trojan.db | grep "###" | wc -l')

    # Informasi sistem dan VPS
    namaos = subprocess.getoutput("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").replace('"', '')
    ipsaya = subprocess.getoutput("curl -s ipv4.icanhazip.com")
    city = subprocess.getoutput("cat /etc/xray/city")

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PREMIUM PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» OS     :** `{namaos.strip()}`
🔰 **» CITY   :** `{city.strip()}`
🔰 **» DOMAIN :** `{DOMAIN}`
🔰 **» IP VPS :** `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)
