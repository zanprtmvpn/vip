from kyt import *
import subprocess
import time
import requests
import random
import datetime as DT

# DELETE SSH ACCOUNT
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    await event.respond("**Username To Be Deleted:**")
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    cmd = f'printf "%s\n" "{user}" | delssh'
    result = subprocess.getoutput(cmd)

    if "not found" in result.lower():
        await event.respond(f"**User** `{user}` **Not Found**")
    else:
        await event.respond(f"**Successfully Deleted** `{user}`")

# CREATE SSH ACCOUNT
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text
    async with bot.conversation(chat) as pw:
    await event.respond("**Password:**")
    pw_input = await bot.wait_for(events.NewMessage(incoming=True))
    pw = pw_input.raw_text
    async with bot.conversation(chat) as exp:
    await event.respond("**Expired Days:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
    try:
        subprocess.run(cmd, shell=True)
    except:
        await event.respond("**User Already Exist**")
        return

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ SSH OVPN ACCOUNT 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Username:** `{user.strip()}`
🔰 **Password:** `{pw.strip()}`
━━━━━━━━━━━━━━━━━
🔰 **Host:** `{DOMAIN}`
🔰 **Port OpenSSH:** `443, 80, 22`
🔰 **Port DNS:** `443, 53, 22`
🔰 **Port Dropbear:** `443, 109`
🔰 **Port Dropbear WS:** `443, 109`
🔰 **Port SSH WS:** `80, 8080, 8081-9999`
🔰 **Port SSH SSL WS:** `443`
🔰 **Port SSH UDP:** `1-65535`
🔰 **Port SSL/TLS:** `222-1000`
🔰 **Port OVPN WS SSL:** `443`
🔰 **Port OVPN SSL:** `443`
🔰 **Port OVPN TCP:** `443, 1194`
🔰 **Port OVPN UDP:** `2200`
🔰 **Proxy Squid:** `3128`
🔰 **BadVPN UDP:** `7100, 7300, 7300`
━━━━━━━━━━━━━━━━━
🔰 **Payload WSS:**  
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
━━━━━━━━━━━━━━━━━
🔰 **OpenVPN WS SSL:** `https://{DOMAIN}:81/ws-ssl.ovpn`
🔰 **OpenVPN SSL:** `https://{DOMAIN}:81/ssl.ovpn`
🔰 **OpenVPN TCP:** `https://{DOMAIN}:81/tcp.ovpn`
🔰 **OpenVPN UDP:** `https://{DOMAIN}:81/udp.ovpn`
━━━━━━━━━━━━━━━━━
🔰 **Save Link Account:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
🔰 **Expired Until:** `{later}`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# SHOW ALL SSH USERS
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    cmd = 'bot-member-ssh'
    result = subprocess.getoutput(cmd)
    
    await event.respond(f"""
**Show All SSH Users**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# TRIAL SSH ACCOUNT
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    await event.respond("**Expired Minutes:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    user = "trialX" + str(random.randint(100, 1000))
    pw = "1"

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} | tmux new-session -d -s {user} "trial trialssh {user} {exp}"'
    try:
        subprocess.run(cmd, shell=True)
    except:
        await event.respond("**User Already Exist**")
        return

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ SSH OVPN TRIAL 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Username:** `{user.strip()}`
🔰 **Password:** `{pw.strip()}`
━━━━━━━━━━━━━━━━━
🔰 **Host:** `{DOMAIN}`
🔰 **Expired Until:** `{exp} Minutes`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# CHECK SSH LOGGED-IN USERS
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    cmd = 'bot-cek-login-ssh'
    result = subprocess.getoutput(cmd)

    await event.respond(f"""
{result}
**Shows Logged In Users SSH Ovpn**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# SSH MANAGER MENU
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    inline = [
        [Button.inline(" TRIAL SSH ", "trial-ssh"),
         Button.inline(" CREATE SSH ", "create-ssh")],
        [Button.inline(" DELETE SSH ", "delete-ssh"),
         Button.inline(" CHECK Login SSH ", "login-ssh")],
        [Button.inline(" SHOW All USER SSH ", "show-ssh"),
         Button.inline(" REGIS IP ", "regis")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ SSH OVPN MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `SSH OVPN`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🔰 **🤖 @sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)