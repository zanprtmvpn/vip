from kyt import *
import subprocess
import time
import requests
import re
import datetime as DT

# CREATE VLESS ACCOUNT
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    await event.respond("**Quota:**")
    quota_input = await bot.wait_for(events.NewMessage(incoming=True))
    quota = quota_input.raw_text

    await event.respond("**Expired Days:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" | addvless'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))
    links = [x.group() for x in re.finditer("vless://(.*)", result)]
    domain = re.search("@(.*?):", links[0]).group(1)
    uuid = re.search("vless://(.*?)@", links[0]).group(1)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ XRAY/VLESS ACCOUNT 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Username:** `{user}`
🔰 **Host Server:** `{domain}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `{quota} GB`
🔰 **Port DNS:** `443, 53`
🔰 **Port TLS:** `222-1000`
🔰 **Port NTLS:** `80, 8080, 8081-9999`
🔰 **NetWork:** `(WS) or (gRPC)`
🔰 **User ID:** `{uuid}`
🔰 **Path Vless:** `(/multi path)/vless`
🔰 **Path Dynamic:** `http://BUG.COM/vless`
🔰 **Pub Key:** `{PUB}`
━━━━━━━━━━━━━━━━━
🔰 **Link TLS:**  
`{links[0]}`
━━━━━━━━━━━━━━━━━
🔰 **Link NTLS:**  
`{links[1].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Link GRPC:**  
`{links[2].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Format OpenClash:**  
`https://{domain}:81/vless-{user}.txt`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{later}`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# CHECK VLESS LOGGED-IN USERS
@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    cmd = 'bot-cek-vless'
    result = subprocess.getoutput(cmd)
    
    await event.respond(f"""
{result}
**Shows Logged In Users VLESS**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# DELETE VLESS ACCOUNT
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    cmd = f'printf "%s\n" "{user}" | delvless'
    result = subprocess.getoutput(cmd)

    if "not found" in result.lower():
        await event.respond("**User Not Found**")
    else:
        await event.respond(f"**Successfully Deleted** `{user}`")

# TRIAL VLESS ACCOUNT
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    await event.respond("**Expired Minutes:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{exp}" | trialvless'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    links = [x.group() for x in re.finditer("vless://(.*)", result)]
    remarks = re.search("#(.*)", links[0]).group(1)
    domain = re.search("@(.*?):", links[0]).group(1)
    uuid = re.search("vless://(.*?)@", links[0]).group(1)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ XRAY/VLESS TRIAL 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Remarks:** `{remarks}`
🔰 **Host Server:** `{domain}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `Unlimited`
🔰 **Port DNS:** `443, 53`
🔰 **Port TLS:** `222-1000`
🔰 **Port NTLS:** `80, 8080, 8081-9999`
🔰 **NetWork:** `(WS) or (gRPC)`
🔰 **User ID:** `{uuid}`
🔰 **Path Vless:** `(/multi path)/vless`
🔰 **Path Dynamic:** `http://BUG.COM/vless`
🔰 **Pub Key:** `{PUB}`
━━━━━━━━━━━━━━━━━
🔰 **Link TLS:**  
`{links[0]}`
━━━━━━━━━━━━━━━━━
🔰 **Link NTLS:**  
`{links[1].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Link GRPC:**  
`{links[2].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{exp} Minutes`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# VLESS MANAGER MENU
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    inline = [
        [Button.inline(" TRIAL VLESS ", "trial-vless"),
         Button.inline(" CREATE VLESS ", "create-vless")],
        [Button.inline(" CHECK VLESS ", "cek-vless"),
         Button.inline(" DELETE VLESS ", "delete-vless")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ VLESS MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `VLESS`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🔰 **🤖 @sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)
