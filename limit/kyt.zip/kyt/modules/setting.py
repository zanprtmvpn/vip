from kyt import *
import subprocess
import time
import requests

# REBOOT SERVER
@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
    cmd = 'reboot'
    await event.edit("Processing...")
    time.sleep(1)
    await event.edit("`Processing Restart Service Server...`")
    time.sleep(1)
    await event.edit("`Processing... 100%\n█████████████████████████ `")
    subprocess.run(cmd, shell=True)
    await event.edit("**» REBOOT SERVER**\n**» 🤖@sabdestore**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# RESTART SERVICE
@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
    cmd = 'systemctl restart xray nginx haproxy server client'
    subprocess.run(cmd, shell=True)
    await event.edit("Processing...")
    time.sleep(1)
    await event.edit("**» Restarting Service Done**\n**» 🤖@sabdestore**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# SPEEDTEST
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
    cmd = 'speedtest-cli --share'
    result = subprocess.getoutput(cmd)
    await event.edit("`Processing... 100%\n█████████████████████████ `")
    await event.respond(f"**{result}**\n**» 🤖@sabdestore**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# BACKUP
@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    await event.respond('**Input Email:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    email = user_input.raw_text
    cmd = f'printf "%s\n" "{email}" | bot-backup'
    try:
        result = subprocess.getoutput(cmd)
        await event.respond(f"```{result}```\n**» 🤖@sabdestore**")
    except:
        await event.respond("**Not Exist**")

# RESTORE
@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    await event.respond('**Input Link Backup:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    link = user_input.raw_text
    cmd = f'printf "%s\n" "{link}" | bot-restore'
    try:
        result = subprocess.getoutput(cmd)
        await event.respond(f"```{result}```\n**» 🤖@sabdestore**")
    except:
        await event.respond("**Link Not Exist**")

# BACKUP & RESTORE MENU
@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
    inline = [
        [Button.inline(" BACKUP", "backup"), Button.inline(" RESTORE", "restore")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PREMIUM PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🤖 **»@sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)

# SETTING MENU
@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
    inline = [
        [Button.inline(" SPEEDTEST", "speedtest"), Button.inline(" BACKUP & RESTORE", "backer")],
        [Button.inline(" REBOOT SERVER", "reboot"), Button.inline(" RESTART SERVICE", "resx")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PREMIUM PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🤖 **»@sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)
