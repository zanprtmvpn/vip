from kyt import *
import subprocess
import time

# CEK INFO VPS
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
    cmd = 'bot-vps-info'.strip()
    
    await event.edit("Processing.")
    await event.edit("Processing..")
    await event.edit("Processing...")
    await event.edit("Processing....")
    time.sleep(3)
    await event.edit("`Processing Info Service Server...`")
    time.sleep(1)
    await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(2)
    await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(3)
    await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(2)
    await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
    time.sleep(0)
    await event.edit("`Processing... 100%\n█████████████████████████ `")
    time.sleep(1)
    await event.edit("`Wait.. Setting up Server Data`")
    
    # Eksekusi perintah dan dapatkan hasilnya
    result = subprocess.getoutput(cmd)

    await event.respond(f"""```{result}```
**🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
