from kyt import *
import subprocess
import time
import requests
import re
import datetime as DT

# CREATE TROJAN ACCOUNT
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    await event.respond("**Quota:**")
    quota_input = await bot.wait_for(events.NewMessage(incoming=True))
    quota = quota_input.raw_text

    await event.respond("**Expired Days:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" | addtr'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))
    links = [x.group() for x in re.finditer("trojan://(.*)", result)]
    domain = re.search("@(.*?):", links[0]).group(1)
    uuid = re.search("trojan://(.*?)@", links[0]).group(1)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ XRAY/TROJAN ACCOUNT 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Username:** `{user}`
🔰 **Host Server:** `{domain}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `{quota} GB`
🔰 **Port DNS:** `443, 53`
🔰 **Port TLS:** `222-1000`
🔰 **User ID:** `{uuid}`
🔰 **Pub Key:** {PUB}
━━━━━━━━━━━━━━━━━
🔰 **Link WS:**  
`{links[0].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Link GRPC:**  
`{links[1].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Format OpenClash:**  
`https://{domain}:81/trojan-{user}.txt`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{later}`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# CHECK TROJAN LOGGED-IN USERS
@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
    cmd = 'bot-cek-tr'
    result = subprocess.getoutput(cmd)
    
    await event.respond(f"""
{result}
**Shows Logged In Users Trojan**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# TRIAL TROJAN ACCOUNT
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    await event.respond("**Expired Minutes:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{exp}" | trialtr'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    links = [x.group() for x in re.finditer("trojan://(.*)", result)]
    remarks = re.search("#(.*)", links[0]).group(1)
    domain = re.search("@(.*?):", links[0]).group(1)
    uuid = re.search("trojan://(.*?)@", links[0]).group(1)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ XRAY/TROJAN TRIAL 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Remarks:** `{remarks}`
🔰 **Host Server:** `{domain}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `Unlimited`
🔰 **Port DNS:** `443, 53`
🔰 **Port TLS:** `222-1000`
🔰 **Path Trojan:** `(/multi path)/trojan-ws`
🔰 **User ID:** `{uuid}`
🔰 **Pub Key:** {PUB}
━━━━━━━━━━━━━━━━━
🔰 **Link WS:**  
`{links[0].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Link GRPC:**  
`{links[1].replace(" ", "")}`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{exp} Minutes`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# DELETE TROJAN ACCOUNT
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    cmd = f'printf "%s\n" "{user}" | deltr'
    result = subprocess.getoutput(cmd)

    if "not found" in result.lower():
        await event.respond("**User Not Found**")
    else:
        await event.respond(f"**Successfully Deleted** `{user}`")

# TROJAN MANAGER MENU
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    inline = [
        [Button.inline(" TRIAL TROJAN ", "trial-trojan"),
         Button.inline(" CREATE TROJAN ", "create-trojan")],
        [Button.inline(" CHECK TROJAN ", "cek-trojan"),
         Button.inline(" DELETE TROJAN ", "delete-trojan")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ TROJAN MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `TROJAN`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🔰 **🤖 @sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)
