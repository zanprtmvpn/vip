from kyt import *
import subprocess
import time
import requests
import re
import json
import base64
import datetime as DT

# CREATE VMESS ACCOUNT
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    await event.respond("**Quota:**")
    quota_input = await bot.wait_for(events.NewMessage(incoming=True))
    quota = quota_input.raw_text

    await event.respond("**Expired Days:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" | addws'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))
    links = [x.group() for x in re.finditer("vmess://(.*)", result)]
    
    decoded_vmess = base64.b64decode(links[0].replace("vmess://", "")).decode("ascii")
    vmess_data = json.loads(decoded_vmess)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ Xray/VMESS ACCOUNT 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Username:** `{user}`
🔰 **Host Server:** `{DOMAIN}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `{quota} GB`
🔰 **Port DNS:** `443, 53`
🔰 **Port TLS:** `222-1000`
🔰 **Port NTLS:** `80, 8080, 8081-9999`
🔰 **Port GRPC:** `443`
🔰 **User ID:** `{vmess_data["id"]}`
🔰 **AlterId:** `0`
🔰 **Security:** `auto`
🔰 **NetWork:** `(WS) or (gRPC)`
🔰 **Path TLS:** `(/multi path)/vmess`
🔰 **ServiceName:** `vmess-grpc`
🔰 **Pub Key:** `{PUB}`
━━━━━━━━━━━━━━━━━
🔰 **Link TLS:**  
`{links[0]}`
━━━━━━━━━━━━━━━━━
🔰 **Format OpenClash:**  
`https://{DOMAIN}:81/vmess-{user}.txt`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{later}`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# CHECK VMESS LOGGED-IN USERS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    cmd = 'bot-cek-ws'
    result = subprocess.getoutput(cmd)
    
    await event.respond(f"""
{result}
**Shows Logged In Users VMESS**
**» 🤖@sabdestore**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# DELETE VMESS ACCOUNT
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    await event.respond('**Username:**')
    user_input = await bot.wait_for(events.NewMessage(incoming=True))
    user = user_input.raw_text

    cmd = f'printf "%s\n" "{user}" | delws'
    result = subprocess.getoutput(cmd)

    if "not found" in result.lower():
        await event.respond("**User Not Found**")
    else:
        await event.respond(f"**Successfully Deleted** `{user}`")

# TRIAL VMESS ACCOUNT
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    await event.respond("**Expired Minutes:**")
    exp_input = await bot.wait_for(events.NewMessage(incoming=True))
    exp = exp_input.raw_text

    await event.edit("Processing... 100%\n█████████████████████████")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    cmd = f'printf "%s\n" "{exp}" | trialws'
    try:
        result = subprocess.getoutput(cmd)
    except:
        await event.respond("**User Already Exist**")
        return

    links = [x.group() for x in re.finditer("vmess://(.*)", result)]
    
    decoded_vmess = base64.b64decode(links[0].replace("vmess://", "")).decode("ascii")
    vmess_data = json.loads(decoded_vmess)

    msg = f"""
━━━━━━━━━━━━━━━━━
**🐾🕊️ Xray/VMESS TRIAL 🕊️🐾**
━━━━━━━━━━━━━━━━━
🔰 **Username:** `{vmess_data["ps"]}`
🔰 **Host Server:** `{DOMAIN}`
🔰 **Host XrayDNS:** `{HOST}`
🔰 **User Quota:** `Unlimited`
🔰 **Port DNS:** `443, 53`
🔰 **Port TLS:** `222-1000`
🔰 **Port NTLS:** `80, 8080, 8081-9999`
🔰 **Port GRPC:** `443`
🔰 **User ID:** `{vmess_data["id"]}`
🔰 **AlterId:** `0`
🔰 **Security:** `auto`
🔰 **NetWork:** `(WS) or (gRPC)`
🔰 **Path TLS:** `(/multi path)/vmess`
🔰 **ServiceName:** `vmess-grpc`
🔰 **Pub Key:** `{PUB}`
━━━━━━━━━━━━━━━━━
🔰 **Link TLS:**  
`{links[0]}`
━━━━━━━━━━━━━━━━━
🔰 **Format OpenClash:**  
`https://{DOMAIN}:81/vmess-{vmess_data["ps"]}.txt`
━━━━━━━━━━━━━━━━━
🔰 **Expired Until:** `{exp} Minutes`
🔰 **🤖@sabdestore**
"""
    await event.respond(msg)

# VMESS MANAGER MENU
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    inline = [
        [Button.inline(" TRIAL VMESS ", "trial-vmess"),
         Button.inline(" CREATE VMESS ", "create-vmess")],
        [Button.inline(" CHECK VMESS ", "cek-vmess"),
         Button.inline(" DELETE VMESS ", "delete-vmess")],
        [Button.inline("‹ Main Menu ›", "menu")]
    ]
    
    data = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ VMESS MANAGER 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `VMESS`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{data["isp"]}`
🔰 **» Country:** `{data["country"]}`
🔰 **🤖 @sabdestore**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)
