from telethon import TelegramClient
import datetime as DT
import requests, time, os, subprocess, re, sys, random, base64, json, math, logging

# Logging untuk debugging
logging.basicConfig(level=logging.INFO)

# Waktu mulai bot
uptime = DT.datetime.now()

# Membaca konfigurasi dari var.txt
def get_var(variable):
    try:
        with open("kyt/var.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                if line.startswith(variable + "="):
                    return line.strip().split('=')[1].strip('"')
    except:
        return None  # Jika variabel tidak ditemukan

# Load konfigurasi dari var.txt
BOT_TOKEN = get_var("BOT_TOKEN")

# Inisialisasi bot tanpa batasan admin
bot = TelegramClient("bot_session", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# Fungsi konversi ukuran file
def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])

# Menjalankan bot
bot.run_until_disconnected()
